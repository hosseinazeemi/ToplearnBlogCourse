﻿using Microsoft.AspNetCore.Components;
using Toplearn_Blog.Shared.Dto.Tag;

namespace Toplearn_Blog.Dashboard.Pages.TagComponents
{
    public partial class TagForm
    {
        [Parameter]
        public TagDto Tag { get; set; }
        [Parameter]
        public EventCallback SubmitCallback { get; set; }
    }
}
